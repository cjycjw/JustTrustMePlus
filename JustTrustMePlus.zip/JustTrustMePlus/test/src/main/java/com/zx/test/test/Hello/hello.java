package com.zx.test.test.Hello;

/**
 * Created by Lyh on
 * 2019/8/23
 */
public class hello  implements tttttttttttttttt{

    @Override
    public void asfasdf() {

    }
}
