package com.zx.test.test.Hello;

/**
 * Created by Lyh on
 * 2019/8/23
 */
public interface tttttttttttttttt {
    public void asfasdf();
}
