package com.zx.Justmeplush.config;

/**
 * Created by lyh on 2019/2/15.
 */

public class MainConfig {
    public static boolean isDebug=true;

}
