package com.zx.Justmeplush.config;

/**
 * Created by lyh on 2019/4/3.
 */

public class Key {
    public static String PACKAGE_NAME="PACKAGE_NAME";
    public static String APP_INFO="APP_INFO";
    public static String MODEL="MODEL";

    public static String ListType="java.util.List";

}
