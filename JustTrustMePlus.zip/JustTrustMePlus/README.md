# JustTrustMePlus (出自小秘圈 四哥)

# 重点说明手机抓包
1. JustTrustMePlus是升级版能够对抗okhttp混淆加密
2. 对于某些apk无法使用charles抓包（我也不知道原因）
3. 手机端抓包可以使用httpCarry
